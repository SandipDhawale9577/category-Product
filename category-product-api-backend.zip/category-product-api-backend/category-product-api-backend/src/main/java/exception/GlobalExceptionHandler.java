package exception;

public class GlobalExceptionHandler {

}
