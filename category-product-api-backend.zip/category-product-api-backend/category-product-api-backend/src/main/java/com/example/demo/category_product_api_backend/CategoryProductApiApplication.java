
package com.example.demo.category_product_api_backend;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CategoryProductApiApplication {
    public static void main(String[] args) {
        SpringApplication.run(CategoryProductApiApplication.class, args);
        System.out.println("Spring Boot Starting...........");
    }
}

