package com.example.demo.category_product_api_backend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CategoryProductApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
